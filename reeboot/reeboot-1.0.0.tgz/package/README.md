# reeboot

> Your personal AI agent. One command to install. Runs locally. Talk to it from anywhere.

---

## Quick Start

```bash
# Install and launch the setup wizard
npx reeboot

# Or install globally
npm install -g reeboot
reeboot setup
reeboot start
```

The wizard will ask for your LLM provider, API key, model, and which channels to enable. After that, `reeboot start` runs the agent — open the WebChat URL it prints, or scan the WhatsApp QR code.

---

## What It Can Do

| Capability | Description |
|---|---|
| **WebChat** | Browser-based chat UI, available instantly at `http://localhost:3000` |
| **WhatsApp** | Scan a QR code — your agent lives in your WhatsApp DMs |
| **Signal** | Connect via a Signal Docker container (json-rpc or polling mode) |
| **Multi-context** | Separate conversation threads (work, personal, projects) |
| **Scheduled tasks** | Ask your agent to remind you or run jobs on a cron schedule |
| **Extensions** | Pi-compatible extension system — tools, compaction, custom prompts |
| **Skills** | Drop Markdown skill files into `~/.reeboot/skills/` for instant capabilities |
| **Packages** | Install community tool packages: `reeboot install npm:reeboot-github-tools` |
| **Daemon mode** | Run as a background service (launchd on macOS, systemd on Linux) |
| **Doctor** | `reeboot doctor` diagnoses your setup before you even start |

---

## Architecture Overview

Reeboot is a single Node.js process. All channels (WhatsApp, Signal, WebChat) connect to the same orchestrator, which routes messages to the AI agent and returns responses.

```
                    ┌──────────────────────────────────┐
                    │           reeboot process          │
                    │                                    │
  WhatsApp ────────►│  ChannelRegistry                  │
  Signal   ────────►│       │                           │
  WebChat  ────────►│   MessageBus ──► Orchestrator     │
  HTTP API ────────►│                       │            │
                    │               AgentRunner (pi)    │
                    │                       │            │
                    │                LLM Provider        │
                    │           (Anthropic / OpenAI …)  │
                    └──────────────────────────────────┘
```

Configuration lives in `~/.reeboot/config.json`. Sessions and conversation history are stored in `~/.reeboot/db/reeboot.db` (SQLite). Extensions are loaded from `~/.reeboot/extensions/` and `~/.reeboot/packages/`.

---

## Configuration Reference

Config file: `~/.reeboot/config.json`

```json
{
  "agent": {
    "provider": "anthropic",
    "apiKey": "sk-ant-...",
    "model": "claude-opus-4-5",
    "name": "Reeboot",
    "turnTimeout": 300000,
    "rateLimitRetries": 3
  },
  "channels": {
    "web": {
      "enabled": true,
      "port": 3000
    },
    "whatsapp": {
      "enabled": false
    },
    "signal": {
      "enabled": false,
      "phoneNumber": "+15551234567",
      "apiUrl": "http://localhost:8080",
      "pollInterval": 1000
    }
  },
  "extensions": {
    "packages": []
  },
  "credentialProxy": {
    "enabled": false
  }
}
```

**Environment variables** (override config values):
- `REEBOOT_API_KEY` — LLM provider API key
- `REEBOOT_PROVIDER` — provider name
- `REEBOOT_MODEL` — model ID
- `REEBOOT_PORT` — HTTP port (default: 3000)

---

## Extension System

Reeboot uses a three-level extension ladder. Pick the right level for what you want to do:

### Level 1 — Skills (Markdown, easiest)

Drop a `SKILL.md` file into `~/.reeboot/skills/<skill-name>/SKILL.md`. The agent reads it as a system-level instruction when the skill is invoked. Great for domain-specific personas, checklists, or prompt templates.

```
~/.reeboot/skills/
  morning-standup/
    SKILL.md        ← "When asked for standup, ask 3 questions then summarise..."
  code-review/
    SKILL.md
```

### Level 2 — Pi Extensions (TypeScript, full tool access)

Drop a `.ts` file into `~/.reeboot/extensions/`. Extensions are pi-compatible — they can register tools, hook into system prompt generation, and intercept messages.

```typescript
// ~/.reeboot/extensions/my-tool.ts
export default {
  tools: [
    {
      name: 'get_weather',
      description: 'Get current weather for a city',
      inputSchema: { ... },
      handler: async ({ city }) => { ... }
    }
  ]
};
```

Reload without restart: `reeboot reload`

### Level 3 — Channel Adapters (TypeScript, custom channels)

Implement the `ChannelAdapter` interface from `reeboot/channels` to add new messaging channels (Telegram, SMS, Slack, etc.):

```typescript
import type { ChannelAdapter } from 'reeboot/channels';

export class TelegramAdapter implements ChannelAdapter {
  // ...
}
```

### Community Packages

Install published packages that bundle tools, extensions, or channel adapters:

```bash
reeboot install npm:reeboot-github-tools
reeboot install npm:reeboot-obsidian-tools
reeboot install git:github.com/you/my-reeboot-pack
reeboot install ./path/to/local-package
```

List installed packages:

```bash
reeboot packages list
```

Uninstall:

```bash
reeboot uninstall reeboot-github-tools
```

**Publishing a community package** — add a `pi` manifest to your `package.json`:

```json
{
  "name": "reeboot-github-tools",
  "pi": {
    "extensions": ["./dist/github-extension.js"],
    "skills": ["./skills/"]
  }
}
```

---

## WhatsApp Setup

1. Enable WhatsApp in your config (`"whatsapp": { "enabled": true }`)
2. Start the agent: `reeboot start`
3. Run the channel login: `reeboot channel login whatsapp`
4. A QR code appears in your terminal — scan it with WhatsApp (Settings → Linked Devices → Link a Device)
5. The agent is now available in your WhatsApp DMs

```
┌─────────────────────────────────────┐
│  ██████░░██░░░░████░░███░░░██████   │
│  ██░░░░░░██░░░░██░░░░██░██░░██      │   ← Scan with WhatsApp
│  ██░░░░░░████░░████░░█████░░██      │
│  ██░░░░░░██░░░░██░░░░██░██░░██      │
│  ██████░░██░░░░████░░███░░░██████   │
└─────────────────────────────────────┘
```

The session persists across restarts (credentials saved in `~/.reeboot/credentials/`).

---

## Signal Setup

Signal requires the [`bbernhard/signal-cli-rest-api`](https://github.com/bbernhard/signal-cli-rest-api) Docker container.

**Step 1 — Link your Signal account**

```bash
docker run -p 8080:8080 \
  -v ~/.reeboot/signal-data:/home/user/.local/share/signal-cli \
  -e MODE=native \
  bbernhard/signal-cli-rest-api:latest
```

Then open `http://localhost:8080/v1/qrcodelink?device_name=reeboot` in your browser and scan the QR with Signal (Settings → Linked Devices → Link new device).

**Step 2 — Run in json-rpc mode (recommended)**

```bash
docker run -p 8080:8080 \
  -v ~/.reeboot/signal-data:/home/user/.local/share/signal-cli \
  -e MODE=json-rpc \
  bbernhard/signal-cli-rest-api:latest
```

**Step 3 — Enable in reeboot config**

```json
"signal": {
  "enabled": true,
  "phoneNumber": "+15551234567",
  "apiUrl": "http://localhost:8080"
}
```

Then: `reeboot start`

---

## CLI Reference

```
reeboot [command] [options]

Commands:
  start         Start the agent server
  stop          Stop the running daemon
  setup         Interactive setup wizard
  status        Show agent and channel status
  doctor        Run pre-flight diagnostics
  reload        Hot-reload extensions and skills
  restart       Gracefully restart the agent

  install <pkg>         Install a pi-compatible package
  uninstall <name>      Uninstall a package

  packages list         List installed packages

  channel list          List channels and their status
  channel login <ch>    Authenticate a channel (whatsapp, signal)
  channel logout <ch>   Disconnect a channel

Options:
  start:
    --daemon              Run as background service (launchd/systemd)
    --no-interactive      Skip prompts (use with --provider etc.)
    --provider <name>     LLM provider
    --api-key <key>       API key
    --model <id>          Model ID
    --channels <list>     Comma-separated channel list
    --name <name>         Agent name

  setup:
    --no-interactive      Non-interactive (use with flags below)
    --provider, --api-key, --model, --channels, --name

  doctor:
    --skip-network        Skip network checks (API key validation, Signal version)
```

---

## Docker

Run reeboot as a container, mounting your config from the host:

```bash
docker run -d \
  -v ~/.reeboot:/home/reeboot/.reeboot \
  -p 3000:3000 \
  --name reeboot \
  reeboot/reeboot:latest
```

Health check:

```bash
curl http://localhost:3000/api/health
# {"status":"ok","uptime":42,"version":"1.0.0"}
```

WebChat is available at `http://localhost:3000`.

**Docker Compose example:**

```yaml
services:
  reeboot:
    image: reeboot/reeboot:latest
    ports:
      - "3000:3000"
    volumes:
      - ~/.reeboot:/home/reeboot/.reeboot
    restart: unless-stopped
```

---

## CI/CD Secrets

To use the GitHub Actions publish pipeline, add these repository secrets:

| Secret | Description |
|---|---|
| `NPM_TOKEN` | npm automation token (`npm token create --type=automation`) |
| `DOCKERHUB_TOKEN` | Docker Hub access token (Hub → Account Settings → Security) |

The workflow automatically publishes to npm and pushes Docker images when you push a `v*` tag:

```bash
git tag v1.0.0
git push origin v1.0.0
```

---

## License

MIT

---

## Links

- [npm package](https://www.npmjs.com/package/reeboot)
- [Docker Hub](https://hub.docker.com/r/reeboot/reeboot)
- [Architecture decisions](../architecture-decisions.md)
